function verificarTriangulo() {
  // obtém elementos da página: Esta etapa vale 2,0 pontos

  // converte dados de entrada: Esta etapa vale 2,0 pontos

  // valida os dados de entrada: Esta etapa vale 2,0 pontos

  // cria as condições para exibir a resposta: Esta etapa vale 2,0 pontos

}
// Cria uma referência e o evento click do botão: Esta etapa vale 1,0 ponto